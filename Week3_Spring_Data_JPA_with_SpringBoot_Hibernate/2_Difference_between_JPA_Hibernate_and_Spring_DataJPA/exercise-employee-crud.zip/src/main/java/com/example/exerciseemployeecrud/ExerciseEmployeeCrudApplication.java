package com.example.exerciseemployeecrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExerciseEmployeeCrudApplication {
    public static void main(String[] args) {
        SpringApplication.run(ExerciseEmployeeCrudApplication.class, args);
    }
}
package com.example.library;

public class App {
    public static void main(String[] args) {
        System.out.println("Library Management App Started");
    }
}
